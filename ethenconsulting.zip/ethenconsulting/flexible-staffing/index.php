<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/flexiblestaffing-banner.jpg" class="w-100" alt="" srcset="">
    <!-- <h1 class="overlay-img">Automobile</h1> -->
</div>
<br>
<div class="container">
    <div class="row">
        <div data-aos="flip-right" class="col-sm-4">
            <?php include("../services-sidebar.php"); ?>
        </div>
        <div class="col-sm-8">
            <img data-aos="fade-up-left" src="../img/find-right-people.jpg" class="w-100" alt="" srcset="">
            <br>
            <br>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div data-aos="fade-up-right" class="para text-justify">
                    <h1>Flexible Staffing</h1>
                    <p>With the market being very unstable, organisations are looking for flexible manpower plan, now more than ever. The concept of staffing has become a new mantra worldwide and has evolved rapidly to address various client requirements. These range from temporary staffing solutions to managing the entire HR processes for this temporary workforce.</p>

                    <p>Ethen provides temporary staffing solutions across industry sectors anywhere in India. The entire HR process right from recruitment and selection, on-boarding, pay rolling, compliance and training to creating management reports is handled by us.</p>
                    <p><b>Our full-service model handles the HR processes from an end-to-end basis to provide you the following benefits:</b></p>
                    <ul class="flexible_points">
                        <li><b>Flexible workforce across various functions</b></li>
                        <li><b>Reduces your time and cost of selection</b></li>
                        <li><b>Helps you to get people very fast</b></li>
                        <li><b>Removes expensive contractual procedures</b></li>
                        <li><b>Helps you comply with all statutory obligations</b></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>