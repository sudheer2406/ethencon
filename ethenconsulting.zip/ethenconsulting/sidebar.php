<div class="side-bar">

<h6 class="sidebar-title text-center">INDUSTRIES</h6>

<ul>
    <li><a href="../automobile" target="_self">Automobile</a></li>
    <li><a href="../banking"   target="_self">Banking Insurance</a></li>
    <li><a href="../bpo-kpo"   target="_self">BPO &amp; KPO</a></li>
    <li><a href="../consumer-services"  target="_self">Consumer &amp; Services</a></li>
    <li><a href="../financial"  target="_self">Financial Services</a></li>
    <li><a href="../fmcg"  target="_self">FMCG</a></li>
    <li><a href="../IT"   target="_self">Information Technology</a></li>
    <li><a href="../infrastructure"   target="_self">Infrastructure</a></li>
    <li><a href="../healthcare"  target="_self">Life Sciences &amp; Healthcare</a></li>
    <li><a href="../manufacturing"  target="_self">Manufacturing &amp; Processes</a></li>
    <li><a href="../retailing"  target="_self">Retailing</a></li>
    <li><a href="../media"  target="_self">Media</a></li>
    <li><a href="../telecommunication.php"  target="_self">Telecommunication</a></li>
</ul>

</div>