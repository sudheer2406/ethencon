<div class="side-bar">

    <h6 class="sidebar-title text-center">SERVICES</h6>

    <ul>
        <li><a href="../flexible-staffing" target="_self">Flexible Staffing</a></li>
        <li><a href="../executive-search">Executive Search</a></li>
        <li><a href="../it-solutions"   target="_self">IT Solutions</a></li>
        <li><a href="../hr-solutions"  target="_self">HR Solutions</a></li>
        <li><a href="../corporate-traininf=g"  target="_self">Corporate Training</a></li>
    </ul>

</div>