<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/Ourteam-1.jpg" class="w-100" alt="" srcset="">
    <!-- <h1 class="overlay-img">Information Technology</h1> -->
</div>
<br>
<div class="container">
    <div class="row mb-5">
        <div class="col-sm-4">
            <div class="team" style="border-top: 4px solid #199bf1">
                <img src="../img/vector.jpg">
                <p class="name">xxxxxxxxx</p>
                <p class="des">FOUNDER AND CEO</p>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="team" style="border-top: 4px solid #199bf1">
                <img src="../img/vector.jpg">
                <p class="name">xxxxxxxxx</p>
                <p class="des">DIRECTOR OPERATIONS</p>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="team" style="border-top: 4px solid #199bf1">
                <img src="../img/vector.jpg">
                <p class="name">xxxxxxxxx</p>
                <p class="des">CENTER HEAD</p>
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>