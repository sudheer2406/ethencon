<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/hr-solutions.jpg" class="w-100" alt="" srcset="">
    <!-- <h1 class="overlay-img-right">Executive Search</h1> -->
</div>
<br>
<div class="container">
    <div class="row">
        <div data-aos="flip-right" class="col-sm-4">
            <?php include("../services-sidebar.php"); ?>
        </div>
        <div class="col-sm-8">
            <img data-aos="fade-up-left" src="../img/hr-1.jpg" class="w-100" alt="" srcset="">
            <br>
            <br>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div data-aos="fade-up-right" class="para text-justify">
                    <h1>HR Solutions</h1>
                    <p>Hucon Indiaȵman Resource Solutions practice aims at collaborating with organisations and developing effective HR interventions to enhance organisational efficiency. Hucon provides solutions that suit the client requirements, keeping in mind the futuristic view of the organisation and also current practices. We offer strategic solutions that help in acquiring, motivating, developing and retaining manpower.</p>

                    <p>As client partner, Hucon develops customised solutions to encourage synergy within different functions. This optimises fixed and other costs, leading to higher productivity.</p>

                    <p><b>Consulting</b></p>

                    <p>We offer a wide range of consulting services to our customer, which helps them to build systems and processes to acquire, engage and develop their human capital. We bring to you a host of solutions to address these very challenges. Backed by our vast domain expertise in the HR space, we offer an array of HR Consulting Solutions that will help you take that big leap into organisational excellence.</p>

                    <p><b>Areas of expertise:</b></p>
                    <ul class="flexible_points">
                        <li><b>Organization Design & Structuring</b></li>
                        <li><b>Performance Management</b></li>
                        <li><b>Role Mapping</b></li>
                        <li><b>KRA & KPI Design</b></li>
                        <li><b>Competency Mapping</b></li>
                        <li><b>Competency Assessment</b></li>
                        <li><b>Performance Appraisal System</b></li>
                        <li><b>Career Planning</b></li>
                        <li><b>Compensation Management</b></li>
                        <li><b>Compensation Benchmarking Studies</b></li>
                        <li><b>Variable pay plan design</b></li>
                        <li><b>Grading</b></li>
                        <li><b>Job Evaluation</b></li>
                        <li><b>Employee Engagement</b></li>
                        <li><b>Employee Engagement Study</b></li>
                        <li><b>Exit Diagnostic Study</b></li>
                    </ul>
                    <p><b>Our clients benefit from:</b></p>
                    <ul class="flexible_points">
                        <li><b>Insights into compensations trends and competitor practices</b></li>
                        <li><b>Informed decision making through HR Statistical Research and comprehensive reports</b></li>
                        <li><b>Clarity in reporting mechanisms, roles and responsibilities, Key Performance Indicators and Key Result Areas</b></li>
                        <li><b>Enhanced employee morale through alignment of reward strategy with performance and market scenario</b></li>
                        <li><b>The competitive advantage underpinned by an engaged workforce.</b></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>