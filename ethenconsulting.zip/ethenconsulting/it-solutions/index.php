<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/data.jpg" class="w-100" alt="" srcset="">
    <!-- <h1 class="overlay-img-right">Executive Search</h1> -->
</div>
<br>
<div class="container">
    <div class="row mb-5">
        <div class="col-sm-6">
            <div data-aos="fade-up-right" class="para text-justify">
                <h1>Brand and Messaging</h1>
                <p>Before you can share your company story with the world, it’s important that you know it yourself. Strong brand messaging is a key component of a strong public relations strategy. Walker Sands has a proven process for success that will identify your brand’s key messages and share them with targeted audience(s).</p>

                <p>Messaging is about communicating a consistent brand to customers, partners, analysts and others. This is especially true when it comes to executing an effective public relations strategy- you want to be sure that your messaging is consistent across all platforms.</p>
            </div>
        </div>
        <div class="col-sm-6">
            <img data-aos="fade-up-left" src="../img/Messaging-mobile-app.png" class="w-100 aos-init aos-animate" alt="" srcset="">
        </div>
    </div>
    <div class="row mb-5">
        <div class="col-sm-6">
            <img data-aos="fade-up-left" src="../img/preview.png" class="w-100 aos-init aos-animate" alt="" srcset="">
        </div>
        <div class="col-sm-6">
            <div data-aos="fade-up-right" class="para text-justify">
                <h1>Landing Page Design</h1>
                <p>A good landing page has only one objective: prompting visitors to do the one action you want them to do and convert. This is why many landing pages don’t have menus or a ton of external links—you want your visitor to complete the call to action, not navigate away or get distracted.</p>

                <p>Your landing page design should be consistent with your overall look so visitors can instantly recognize and associate it with your brand. This typically means using the same color scheme and design elements from your general website. It can be a tough line to walk, though, because landing pages should look different from your overall website—they’re generally simpler and don’t include navigation, for example. Nonetheless, the branding and colors will often remain the same.</p>
            </div>
        </div>
    </div>
    <div class="row mb-5">
        <div class="col-sm-6">
            <div data-aos="fade-up-right" class="para text-justify">
                <h1>E-Commerce :</h1>
                <p>With a decade of Industry experience, B2C Info Solutions is engaged in designing & developing end-to- end E-commerce solutions making its headway in helping global entrepreneurs to transform their brands online. We design secured, impeccable and flawless tailor-made E-commerce websites for global promotion of your products and services.</p>

                <p>Morever, we help e-commerce businesses succeed in their daily operation by empowering fully functional custom-made e-commerce systems to integrate with CRM and ERP modules by creating an integrated environment to control over your e-commerce growth.</p>
            </div>
        </div>
        <div class="col-sm-6">
            <img data-aos="fade-up-left" src="../img/Policy-uncertainty-in-Indian-e-commerce.jpg" class="w-100 aos-init aos-animate" alt="" srcset="">
        </div>
    </div>
    <div class="row mb-5">
        <div class="col-sm-6">
            <img data-aos="fade-up-left" src="../img/mobile-application-development.jpg" class="w-100 aos-init aos-animate" alt="" srcset="">
        </div>
        <div class="col-sm-6">
            <div data-aos="fade-up-right" class="para text-justify">
                <h1>Mobile App Development</h1>
                <p>From concept to development, Ethen covers the entire mobile app development cycle, no matter how diverse or complex your needs are. Our ability to meet your needs stem from our team of experts, who have years of experience in global app solution services and product engineering industries.</p>

                <p>We have a team of experts (UI/UX designers, full stack developers, and quality analysts) in our work centers to deliver strategically designed and creatively crafted mobile application development services to take your business to the next level.</p>
            </div>
        </div>
    </div>
    <div class="row mb-5">
        <div class="col-sm-6">
            <div data-aos="fade-up-right" class="para text-justify">
                <h1>CRM</h1>
                <p>Ethen is well known to the world for maintaining quality customer relationships. CRM works diagonally in all departments to match customer-centric thinking. The benefits of such an interactive and/or connected system is that it is cost effective, increases efficiency and improves customer satisfaction. At Ethen, our foremost approach to CRM solutions is very unique. Ethen’s CRM software applications are completely based on a comprehensive understanding of the exclusive needs of our customers. With our salient approach, we deliver purpose-built, flexible Customer Relationship Management (CRM) solutions, which help you to achieve your targets very quickly and effectively.</p>
            </div>
        </div>
        <div class="col-sm-6">
            <img data-aos="fade-up-left" src="../img/CRM-Facebook.png" class="w-100 aos-init aos-animate" alt="" srcset="">
        </div>
    </div>
    <div class="row mb-5">
        <div class="col-sm-6">
            <img data-aos="fade-up-left" src="../img/download.png" class="w-100 aos-init aos-animate" alt="" srcset="">
        </div>
        <div class="col-sm-6">
            <div data-aos="fade-up-right" class="para text-justify">
                <h1>Content Management System</h1>
                <p>Hucon has the skills and the experience to use content management systems in order to create excellent websites that are not only beautiful and intuitive, but ideal for your particular business and situation. Our engineers and programmers have large amounts of experience with many different systems, and can create a website that is prepared to deliver great content quickly and without issues that can arise with in-house website creation.</p>
                <p>When you choose Hucon to build your website through content management systems, and you will see how easy it is to publish, update, and maintain content on a website that is modern and professional. Outsourcing your content management system requirements to us is the perfect way to optimize your website budget, and create a great website at a minimum of cost.</p>
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>