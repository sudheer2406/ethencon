<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/about-us.jpg" class="w-100" alt="" srcset="">
    <!-- <h1 class="overlay-img">Information Technology</h1> -->
</div>
<br>
<div class="container">
    <div class="row mb-5">
        <div class="col-sm-6 text-justify">
            <h1>Company Profile</h1>
            <p>Ethen Consulting is an Integrated HR Service Provider for all Corporates all over India. We are backed by a good ERP and enough experience in HR and related activities. Ethen Consulting was launched in April 2008, with an aim to grow into a one stop shop for all HR requirements for clients in India. It has helped generate career opportunities for more than a million individuals in India. Ethen Consulting offers the broadest HR service portfolio from Executive Search, Staffing, Consulting and Outsourcing to Training. Ethen Consulting is present in 3 locations in Hyderabad. Our Forte is Recruitment of IT, ITeS, Engineering, Finance, HR, Manufacturing, Agri, Pharma, Admin, Sales & Marketing professionals. Recruitment also includes screening, conducting technical interviews, and aptitude tests if necessary. Our endeavor is to partner with you in hiring the best Talent. Ethen Consulting team consists of people from a variety of backgrounds who have held key recruitment roles in major companies. Our success is based on the depth and breadth of experience our team has, in every industry and our knowledge and understanding of the local markets. Hucon means (Hu-Human Con-Consulting). Ethen Consulting promises to deliver professional and quality services to its stake holders. Anchored on the values of integrity, transparency, growth, and diversity Ethen Consulting believes in keeping its promise in every initiative that it undertakes.</p>
        </div>
        <div class="col-sm-6">
            <img src="../img/it-2.jpg" class="w-100 mt-5" alt="" srcset="">
        </div>
    </div>
    <div class="row">
        <div data-aos="flip-right" class="col-sm-6">
            <div class="para text-center join-us mb-5" style="background-color: #3a3d4f;padding: 10px;"> 
                <h6>Depth of experience</h6>

                <p>We have experienced specialist recruiters</p>
            </div>
        </div>
        <div data-aos="flip-right" class="col-sm-6">
            <div class="para text-center join-us mb-5" style="background-color: #9bc3e4;padding: 10px;"> 
                <h6>Non-commission structure</h6>

                <p>We work as a team instead of competing for commissions</p>               
            </div>
        </div>
    </div>
    <div class="row">
        <div data-aos="flip-right" class="col-sm-6">
            <div class="para text-center join-us mb-5" style="background-color: #3a3d4f;padding: 10px;"> 
                <h6>Stable leadership</h6>

                <p>Our leadership team has an average tenure of experience with Ethen</p>
            </div>
        </div>
        <div data-aos="flip-right" class="col-sm-6">
            <div class="para text-center join-us mb-5" style="background-color: #9bc3e4;padding: 10px;"> 
                <h6>Consistency of service</h6>

                <p>Organically grown and promote from within</p>           
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>