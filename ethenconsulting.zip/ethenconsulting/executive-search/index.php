<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/executive-banner.jpg" class="w-100" alt="" srcset="">
    <h1 class="overlay-img-right">Executive Search</h1>
</div>
<br>
<div class="container">
    <div class="row">
        <div data-aos="flip-right" class="col-sm-4">
            <?php include("../services-sidebar.php"); ?>
        </div>
        <div class="col-sm-8">
            <img data-aos="fade-up-left" src="../img/executive-1.jpg" class="w-100" alt="" srcset="">
            <br>
            <br>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div data-aos="fade-up-right" class="para text-justify">
                    <h1>Executive Search</h1>
                    <p>Executive search consultants need to have a better understanding of the client requirements, now more than ever. They also need to be very good in understanding the industry segments and talent base to ensure identification of the best and most suitable talent for your organisation.</p>

                    <p>Hucon Executive Search specialises in helping organisations find the best candidates, to suit their requirements, across various fields of expertise. Our business team includes highly qualified Consultants who correspond and share their point of view and counsel with our clients and have a deep understanding of their needs. This helps us identify the best candidate in the most timely and effective manner.</p>

                    <p>In order to recruit senior management across different industries, Hucon employs a rigorous executive search process which involves identifying, attracting, assessing and on-boarding the best talent that the industry has to offer. We provide senior-level executive recruiting services on a retainer basis for companies.</p>

                    <p><b>The industry segments that we serve are:</b></p>
                    <ul class="flexible_points">
                        <li><b>Flexible workforce across various functions</b></li>
                        <li><b>Reduces your time and cost of selection</b></li>
                        <li><b>Helps you to get people very fast</b></li>
                        <li><b>Removes expensive contractual procedures</b></li>
                        <li><b>Helps you comply with all statutory obligations</b></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>