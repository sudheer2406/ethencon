<?php
include("../header.php");
?>

<div class="row">
    <img src="../img/join-us-banner.jpg" class="w-100" alt="" srcset="">
    <!-- <h1 class="overlay-img">Information Technology</h1> -->
</div>
<br>
<div class="container">
    <div class="row mb-5">
        <div class="col-sm-12">
            <h1 class="join_ethen text-center mb-3">Join Ethen</h1>
            <p class="text-center">Join one of our teams and you'll be working for one of the best names in the industry.</p>
            <p class="text-center">As a recruitment consultant, you can choose the path your career takes. Want to lead a team of consultants and see them beat targets every quarter? Want to develop your career in Human Resource recruitment? Want to be the highest biller? Choose a career with Hucon and you can.  Plus you’ll receive the best rewards, training, support, and development opportunities in the industry.</p>
        </div>
    </div>
    <div class="row">
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/your-role.jpg" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #3a3d4f;padding: 10px;"> 
                <h6>Your Role</h6>

                <p><b>Ethen Solutions Changes Lives for People through Creating
                Opportunity to Reach Potential</b></p>

                <p>We are specialist recruiters. &nbsp;All our consultants are experts in their industry and only recruit into
                    their specific market, which gives our customers the best insight and widest reach during their
                recruitment process.</p>


                <p>The role of a Ethen recruitment consultant combines business development and commercial
                    customer service, generating revenue by successfully engaging with clients, candidates and
                colleagues.</p> 

                <p><b>The key responsibilities of a recruitment consultant include:</b></p>             

                <h5 style="color: #fff;"><strong>- Identifying and developing client/business relationships in a competitive environment</strong></h5>

                <h5 style="color: #fff;"><strong>- Advising on and selling the most appropriate solution for attracting candidates and
                maintaining a candidate database</strong></h5>

                <h5 style="color: #fff;"><strong>- Assessing and responding to the needs of each particular client or assignment</strong></h5>

                <h5 style="color: #fff;"><strong>- Sourcing suitable candidates and briefing them on the opportunities offered by the client</strong></h5>

                <h5 style="color: #fff;"><strong>- Managing the process through interview to offer stage and beyond</strong></h5>

                <h5 style="color: #fff;"><strong>- Offering CV, interview and general career advice</strong></h5>

                <h5 style="color: #fff;"><strong>- Networking to build business information that can be converted into commercial
                opportunities</strong></h5>

            </div>
        </div>
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/skill.png" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #9bc3e4;padding: 10px;"> 
                <h6>Use Your Skills</h6>

                <p><b>We know there are particular qualities that make people successful in our organisation.</b></p>

                <p>Many of those skills are easily transferred from your current or past work experience – not
                    necessarily in recruitment. Have you ever had to negotiate with someone? Had to adapt your
                approach depending on your audience? Ever had to push yourself to achieve the best results?</p>


                <p>The ability to be compelling and persuasive, develop relationships and work as part of a team, meet
                    targets and compete for the best results is what will set you apart as a successful recruitment
                consultant. &nbsp;And recruitment can be tough; you must be able to overcome adversity.</p> 

                <p>At Ethen, we create opportunities for people to reach their potential. If you feel you've got what it
                takes, we’d love to hear from you</p>               
            </div>
        </div>
    </div>
    <div class="row">
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/team.jpg" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #3a3d4f;padding: 10px;"> 
                <h6>A team thats diverse</h6>

                <p>At Ethen we know that a diverse team brings different perspectives and insight to our business,
                generating creativity, problem-solving and sustainability that wouldn’t otherwise be possible.</p>

                <p>Our inclusion promise creates opportunities for everyone. Ethen is about recognizing and
                    appreciating that every individual is different and helps us make sure our people are comfortable
                bringing their true selves to work.</p>

                <p>It includes a broad range of activities, networks, and memberships.</p>
            </div>
        </div>
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/product.jpg" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #9bc3e4;padding: 10px;"> 
                <h6>Proud to give something back</h6>

                <p>Giving back to others is part of our culture.  We live and work in the communities we serve, and we encourage all our people to get involved.  We do a lot and we're proud of it.</p>

                <p>Our people undertake all kinds of challenges to help raise money for charity and change people's lives. Celebrating our activities through our internal communication and shares ideas across. As a consulting unit, we take our responsibility to the environment seriously and are constantly looking at ways to minimize and mitigate our environmental impact.</p>           
            </div>
        </div>
    </div>
    <div class="row">
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/development.jpg" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #3a3d4f;padding: 10px;"> 
                <h6>Talent development</h6>

                <p>HUCON is a sales focused environment, offering a clear career path with training and development
                designed to support you and help you to reach your potential.</p>

                <p>We combine leading-edge digital learning technology with structured face to face training sessions.
                Our blended learning approach means you can learn in the way that's best for you.</p>
            </div>
        </div>
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/womensucess.png" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #9bc3e4;padding: 10px;"> 
                <h6>Women succeed at work</h6>

                <p>From the beginning HUCON Solutions has been on the forefront to empower women&nbsp;with the aim to
                maximize Women contribution at all levels across our business. Since then, we have:</p>

                <h5 style="color: #fff;"><strong>- Partnered with ERPS which help work from home.</strong></h5>

                <h5 style="color: #fff;"><strong>- Regularly publish case studies/role models - ‘Real People and Real Stories’.</strong></h5>               
            </div>
        </div>
    </div>
    <div class="row">
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/carrer.png" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #3a3d4f;padding: 10px;"> 
                <h6>Career progression</h6>

                <p>We know how important your career is to you. It’s important to us
                    too! That’s why we have a clear and transparent career path with
                    onsite opportunities, supported by our industry-renowned training
                and development.</p>

                <p>Our Purpose is to changes lives for people through creating an
                    opportunity to reach potential’. That’s true for our own people as
                    well as our candidates and clients. We promote from within, based
                on merit.</p>  
            </div>
        </div>
        <div data-aos="flip-right" class="col-sm-6">
            <img src="../img/reward.png" class="w-100" alt="" srcset="">
            <div class="para text-justify join-us mb-5" style="background-color: #9bc3e4;padding: 10px;"> 
                <h6>Rewarding success</h6>
                <p>At HUCON, rewards are more than just cash incentives. But our competitive basic salaries, personal
                and team-based bonuses and additional incentives are a great start.</p>

                <p>We create opportunities for our people to succeed. We make success fun as well as rewarding and
                we care about our colleagues. Our collaborative, team-based structure helps.</p>

                <p><b>Here's what you can look forward to at HUCON:</b></p>

                <h5 style="color: #fff;"><strong>- Competitive basic salary</strong></h5>

                <h5 style="color: #fff;"><strong>- Minimum of 24 days' annual leave per annum</strong></h5>

                <h5 style="color: #fff;"><strong>- Incentive schemes and competitions</strong></h5>

                <h5 style="color: #fff;"><strong>- Regular social functions and organised sporting activities</strong></h5>

                <h5 style="color: #fff;"><strong>- Recreation and retreat events</strong></h5>

                <h5 style="color: #fff;"><strong>- Corporate social responsibility activities</strong></h5>              
            </div>
        </div>
    </div>
</div>
<?php include("../footer.php"); ?>